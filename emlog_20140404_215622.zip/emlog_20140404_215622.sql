#version:emlog 5.2.1
#date:2014-04-04 21:56
#tableprefix:em_
DROP TABLE IF EXISTS em_attachment;
CREATE TABLE `em_attachment` (
  `aid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `blogid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) NOT NULL DEFAULT '0',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `addtime` bigint(20) NOT NULL DEFAULT '0',
  `width` smallint(5) NOT NULL DEFAULT '0',
  `height` smallint(5) NOT NULL DEFAULT '0',
  `mimetype` varchar(40) NOT NULL DEFAULT '',
  `thumfor` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`),
  KEY `blogid` (`blogid`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO em_attachment VALUES('2','3','7b59b564034f78f030b23ee378310a55b2191c9d.jpg','284746','http://xssydx-emlog.stor.sinaapp.com/5c0a1395594511.jpg','1395594512','0','0','image/jpeg','0');
INSERT INTO em_attachment VALUES('4','6','IMG_3232.JPG','84257','http://xssydx-emlog.stor.sinaapp.com/73751395768393.jpg','1395768393','0','0','image/jpeg','0');
INSERT INTO em_attachment VALUES('5','0','IMG_1050.JPG','96765','http://xssydx-emlog.stor.sinaapp.com/db931395768697.jpg','1395768697','0','0','image/jpeg','0');
INSERT INTO em_attachment VALUES('6','7','IMG_1050.JPG','96765','http://xssydx-emlog.stor.sinaapp.com/db931395768778.jpg','1395768779','0','0','image/jpeg','0');
INSERT INTO em_attachment VALUES('7','7','IMG_1051.JPG','127404','http://xssydx-emlog.stor.sinaapp.com/ac341395768779.jpg','1395768779','0','0','image/jpeg','0');
INSERT INTO em_attachment VALUES('8','7','IMG_1052.JPG','152558','http://xssydx-emlog.stor.sinaapp.com/d5a41395768779.jpg','1395768779','0','0','image/jpeg','0');
INSERT INTO em_attachment VALUES('9','7','IMG_1054.JPG','133793','http://xssydx-emlog.stor.sinaapp.com/b1631395768779.jpg','1395768779','0','0','image/jpeg','0');
INSERT INTO em_attachment VALUES('10','7','IMG_1056.JPG','110660','http://xssydx-emlog.stor.sinaapp.com/86de1395768779.jpg','1395768780','0','0','image/jpeg','0');
INSERT INTO em_attachment VALUES('14','11','Koala.jpg','29566','../content/uploadfile/201403/thum-06d31396282654.jpg','1396282654','420','315','image/jpeg','13');
INSERT INTO em_attachment VALUES('13','11','Koala.jpg','780831','../content/uploadfile/201403/06d31396282654.jpg','1396282654','1024','768','image/jpeg','0');

DROP TABLE IF EXISTS em_blog;
CREATE TABLE `em_blog` (
  `gid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL,
  `content` longtext NOT NULL,
  `excerpt` longtext NOT NULL,
  `alias` varchar(200) NOT NULL DEFAULT '',
  `author` int(10) NOT NULL DEFAULT '1',
  `sortid` tinyint(3) NOT NULL DEFAULT '-1',
  `type` varchar(20) NOT NULL DEFAULT 'blog',
  `views` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `comnum` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attnum` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `top` enum('n','y') NOT NULL DEFAULT 'n',
  `hide` enum('n','y') NOT NULL DEFAULT 'n',
  `checked` enum('n','y') NOT NULL DEFAULT 'y',
  `allow_remark` enum('n','y') NOT NULL DEFAULT 'y',
  `password` varchar(255) NOT NULL DEFAULT '',
  `cover` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`gid`),
  KEY `date` (`date`),
  KEY `author` (`author`),
  KEY `sortid` (`sortid`),
  KEY `type` (`type`),
  KEY `views` (`views`),
  KEY `comnum` (`comnum`),
  KEY `hide` (`hide`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO em_blog VALUES('8','域名空间购买心得','1396022091','<p>\r\n	最近想搞个个人网站，域名在godaddy上买的。想顺便空间也在上面买了。没想到买了2次空间，都买错了。\r\n</p>\r\n<p>\r\n	第一次买的是Website Builder Personal 一年只要70多块钱啊，感觉好便宜。都没犹豫就买了。\r\n</p>\r\n<p>\r\n	买了之后发现没有FTP，没有mysql，只能选择theme主题，然后修改。。。。。\r\n</p>\r\n<p>\r\n	第二次买的是Quick Shopping Cart - Economy Edition 一年将近要400了，跟我同事说的300多一年差不多了，应该对了吧。\r\n</p>\r\n<p>\r\n	买了之后发现也是没有FTP，没有mysql，是拿来做商城的，只能简单修改做商城。。。。。\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	把两个东西都取消之后，还顺带给godaddy客服写了个段子：\r\n</p>\r\n<p>\r\n	<span style=\"line-height:1.5;\">Hi,</span>\r\n</p>\r\n<p>\r\n	I have canceled my web hosting,Please refund me.Thanks.<br />\r\nMy visa card \r\nnumber is ************** 4033\r\n</p>\r\n<p>\r\n	客服回的还挺快，瞬间觉得自己英文没白学。\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	这几天有点忙，过阵子再折腾下吧。\r\n</p>','','','1','2','blog','4','0','0','n','n','y','y','','');
INSERT INTO em_blog VALUES('2','百度云盘图片测试','1389535359','<img src=\"http://d.pcs.baidu.com/thumbnail/8ad8520ee1ad6778962c8a1f894761b3?fid=1997337168-250528-3824906006&time=1389535298&rt=pr&sign=FDTAER-DCb740ccc5511e5e8fedcff06b081203-GLjL2tul7aJaW9KA3QDnS4FbqVs%3D&expires=8h&prisign=amMwnVibYf88f2TB/V4FApSN5rJwOqzRd3VKNKTQ53AEKBJxWcpoyvgqed3TucCofWlE5y7Vq0gL9lQi8Lp8+RoXS69TsChhAroHLuuZ1uozUG7s5CSdELgnP1BH+ty6tuQsmA72KyTSn8YnIkQnGv7SEug66iIndt9qVvQXRBFwba0VAqyZNhzldIEYuGIm6/FKMWFiM+B82IL8vHdvaypvCseuLD3z&r=281169594&size=c850_u580&quality=100\" alt=\"\" data-pinit=\"registered\" />','','','1','-1','blog','7','0','0','n','n','y','y','','');
INSERT INTO em_blog VALUES('3','改写记录','1389535980','<a target=\"_blank\" href=\"http://xssydx-emlog.stor.sinaapp.com/5c0a1395594511.jpg\" id=\"ematt:2\"><img src=\"http://xssydx.sinaapp.com/p://xssydx-emlog.stor.sinaapp.com/5c0a1395594511.jpg\" title=\"点击查看原图\" alt=\"7b59b564034f78f030b23ee378310a55b2191c9d.jpg\" border=\"0\" width=\"0\" height=\"0\" /></a>\r\n<p>\r\n	目前已完成\r\n</p>\r\n<p>\r\n	1.mysql\r\n</p>\r\n<p>\r\n	2.cache读写mc\r\n</p>\r\n<p>\r\n	接下来还需要\r\n</p>\r\n<p>\r\n	图片上传调用Storage服务\r\n</p>\r\n<p>\r\n	<a href=\"http://sae.sina.com.cn/?m=storage&amp;app_id=xssydx&amp;ver=0\">http://sae.sina.com.cn/?m=storage&amp;app_id=xssydx&amp;ver=0</a> \r\n</p>\r\n<p>\r\n	<a href=\"http://sae.sina.com.cn/?m=devcenter&amp;catId=204\">http://sae.sina.com.cn/?m=devcenter&amp;catId=204</a> \r\n</p>\r\n<p>\r\n	模板调整\r\n</p>\r\n<p>\r\n	美化\r\n</p>\r\n<p>\r\n	<a target=\"_blank\" href=\"http://xssydx-emlog.stor.sinaapp.com/5c0a1395594511.jpg\" id=\"ematt:2\"><img src=\"http://xssydx.sinaapp.com/p://xssydx-emlog.stor.sinaapp.com/5c0a1395594511.jpg\" title=\"点击查看原图\" alt=\"7b59b564034f78f030b23ee378310a55b2191c9d.jpg\" border=\"0\" width=\"0\" height=\"0\" /><img src=\"http://xssydx-emlog.stor.sinaapp.com/5c0a1395594511.jpg\" width=\"354\" height=\"500\" alt=\"\" data-pinit=\"registered\" /></a>\r\n</p>\r\n<p>\r\n	<a target=\"_blank\" href=\"http://xssydx-emlog.stor.sinaapp.com/5c0a1395594511.jpg\" id=\"ematt:2\"><img src=\"http://xssydx.sinaapp.com/p://xssydx-emlog.stor.sinaapp.com/5c0a1395594511.jpg\" title=\"点击查看原图\" alt=\"7b59b564034f78f030b23ee378310a55b2191c9d.jpg\" border=\"0\" width=\"0\" height=\"0\" /><a target=\"_blank\" href=\"http://xssydx-emlog.stor.sinaapp.com/5c0a1395594511.jpg\" id=\"ematt:2\"><img src=\"http://xssydx.sinaapp.com/p://xssydx-emlog.stor.sinaapp.com/5c0a1395594511.jpg\" title=\"点击查看原图\" alt=\"7b59b564034f78f030b23ee378310a55b2191c9d.jpg\" border=\"0\" width=\"0\" height=\"0\" /></a></a>\r\n</p>','','','1','2','blog','4','0','1','n','n','y','y','','');
INSERT INTO em_blog VALUES('4','手机','1389537104','手机查看，写文章测试','','','1','2','blog','8','0','0','n','n','y','y','','');
INSERT INTO em_blog VALUES('5','遗留问题记录','1395767855','<p>\r\n	<span style=\"line-height:1.5;\"><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span style=\"line-height:1.5;\">域名带www指向正常，但是不带www指向不正确</span> \r\n</p>\r\n<p>\r\n	批量上传图片，提示权限不足\r\n</p>\r\n<p>\r\n	单个上传图片后，插入到文本中时，width和height都为0，导入插入图片看不到\r\n</p>','','','1','3','blog','10','2','0','n','n','y','y','','');
INSERT INTO em_blog VALUES('6','马上有钱','1395768373','<a target=\"_blank\" href=\"http://xssydx-emlog.stor.sinaapp.com/73751395768393.jpg\" id=\"ematt:4\"><img src=\"http://xssydx-emlog.stor.sinaapp.com/73751395768393.jpg\" width=\"200\" height=\"150\" title=\"点击查看原图\" alt=\"点击查看原图\" data-pinit=\"registered\" /></a>','','','1','1','blog','9','0','1','n','n','y','y','','');
INSERT INTO em_blog VALUES('7','PP 百达翡丽','1395768678','<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<a target=\"_blank\" href=\"http://xssydx-emlog.stor.sinaapp.com/db931395768778.jpg\" id=\"ematt:6\"><img src=\"http://xssydx-emlog.stor.sinaapp.com/db931395768778.jpg\" width=\"200\" height=\"150\" title=\"点击查看原图\" alt=\"点击查看原图\" data-pinit=\"registered\" /></a> \r\n</p>\r\n<p>\r\n	<a target=\"_blank\" href=\"http://xssydx-emlog.stor.sinaapp.com/ac341395768779.jpg\" id=\"ematt:7\"><img src=\"http://xssydx-emlog.stor.sinaapp.com/ac341395768779.jpg\" width=\"149\" height=\"200\" title=\"点击查看原图\" alt=\"点击查看原图\" data-pinit=\"registered\" /></a> \r\n</p>\r\n<p>\r\n	<a target=\"_blank\" href=\"http://xssydx-emlog.stor.sinaapp.com/d5a41395768779.jpg\" id=\"ematt:8\"><img src=\"http://xssydx-emlog.stor.sinaapp.com/d5a41395768779.jpg\" width=\"149\" height=\"200\" title=\"点击查看原图\" alt=\"点击查看原图\" data-pinit=\"registered\" /></a> \r\n</p>\r\n<p>\r\n	<a target=\"_blank\" href=\"http://xssydx-emlog.stor.sinaapp.com/b1631395768779.jpg\" id=\"ematt:9\"><img src=\"http://xssydx-emlog.stor.sinaapp.com/b1631395768779.jpg\" width=\"149\" height=\"200\" title=\"点击查看原图\" alt=\"点击查看原图\" data-pinit=\"registered\" /></a> \r\n</p>\r\n<p>\r\n	<a target=\"_blank\" href=\"http://xssydx-emlog.stor.sinaapp.com/86de1395768779.jpg\" id=\"ematt:10\"><img src=\"http://xssydx-emlog.stor.sinaapp.com/86de1395768779.jpg\" width=\"149\" height=\"200\" title=\"点击查看原图\" alt=\"点击查看原图\" data-pinit=\"registered\" /></a> \r\n</p>\r\n<p>\r\n	<img src=\"http://www.xssydx.com/admin/editor/plugins/emoticons/images/5.gif\" border=\"0\" alt=\"\" /><img src=\"http://www.xssydx.com/admin/editor/plugins/emoticons/images/5.gif\" border=\"0\" alt=\"\" /><img src=\"http://www.xssydx.com/admin/editor/plugins/emoticons/images/5.gif\" border=\"0\" alt=\"\" />\r\n</p>','','','1','1','blog','17','0','5','n','n','y','y','','');
INSERT INTO em_blog VALUES('9','建站心得','1396196943','<p>\r\n	搞了好多天，终于把自己的网站搞起来了<img src=\"http://www.xssydx.com/admin/editor/plugins/emoticons/images/0.gif\" border=\"0\" alt=\"\" />\r\n</p>\r\n<p>\r\n	godaddy的web hosting 配合 域名一起用起来方便好多\r\n</p>\r\n<p>\r\n	<span style=\"line-height:1.5;\">最重要的是原来godaddy的web hosting有中文的操作面板 cPanel</span>\r\n</p>\r\n<p>\r\n	<span style=\"line-height:1.5;\">新建网站还是搬迁过来都比较直观<img src=\"http://www.xssydx.com/admin/editor/plugins/emoticons/images/23.gif\" border=\"0\" alt=\"\" />&nbsp;</span>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	今天又学到了PuTTY通过SSH连接服务器，使用<span style=\"color:#333333;font-family:\'Helvetica Neue\', \'Segoe UI\', Segoe, Helvetica, Arial, \'Lucida Grande\', sans-serif;font-size:14px;line-height:20px;white-space:normal;background-color:#FFFFFF;\">The public and private key的方法。</span>\r\n</p>\r\n<p>\r\n	<span style=\"color:#333333;font-family:\'Helvetica Neue\', \'Segoe UI\', Segoe, Helvetica, Arial, \'Lucida Grande\', sans-serif;font-size:14px;line-height:20px;white-space:normal;background-color:#FFFFFF;\"><br />\r\n</span>\r\n</p>','','','1','2','blog','3','0','0','n','n','y','y','','');
INSERT INTO em_blog VALUES('11','考拉','1396282587','<a target=\"_blank\" href=\"http://www.xssydx.com/content/uploadfile/201403/06d31396282654.jpg\" id=\"ematt:13\"><img src=\"http://www.xssydx.com/content/uploadfile/201403/thum-06d31396282654.jpg\" title=\"点击查看原图\" alt=\"Koala.jpg\" border=\"0\" width=\"420\" height=\"315\" data-pinit=\"registered\" /></a>','','','1','-1','blog','1','0','1','n','n','y','y','','http://www.xssydx.com/content/uploadfile/201403/coverthum-06d31396282654.jpg\" title=\"点击查看原图\" alt=\"Koala.jpg');
INSERT INTO em_blog VALUES('12','','1396282755','','','','1','-1','blog','0','0','0','n','y','y','y','','');
INSERT INTO em_blog VALUES('13','','1396285233','','','','1','-1','blog','0','0','0','n','y','y','y','','');

DROP TABLE IF EXISTS em_comment;
CREATE TABLE `em_comment` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `gid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `date` bigint(20) NOT NULL,
  `poster` varchar(20) NOT NULL DEFAULT '',
  `comment` text NOT NULL,
  `mail` varchar(60) NOT NULL DEFAULT '',
  `url` varchar(75) NOT NULL DEFAULT '',
  `ip` varchar(128) NOT NULL DEFAULT '',
  `hide` enum('n','y') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`cid`),
  KEY `gid` (`gid`),
  KEY `date` (`date`),
  KEY `hide` (`hide`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO em_comment VALUES('1','5','0','1396199115','老徐','可以评论吗？','bao0541@live.cn','http://www.xssydx.com/','113.119.161.192','n');
INSERT INTO em_comment VALUES('2','5','0','1396199160','沙发','试试看','','','113.119.161.192','n');

DROP TABLE IF EXISTS em_options;
CREATE TABLE `em_options` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(255) NOT NULL,
  `option_value` longtext NOT NULL,
  PRIMARY KEY (`option_id`),
  KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;

INSERT INTO em_options VALUES('1','blogname','老徐');
INSERT INTO em_options VALUES('2','bloginfo','行动是治愈恐惧的良药，而犹豫、拖延将不断滋养恐惧。');
INSERT INTO em_options VALUES('3','site_title','老徐');
INSERT INTO em_options VALUES('4','site_description','老徐的生活琐碎，心得分享');
INSERT INTO em_options VALUES('5','site_key','生活 分享');
INSERT INTO em_options VALUES('6','log_title_style','0');
INSERT INTO em_options VALUES('7','blogurl','http://www.xssydx.com/');
INSERT INTO em_options VALUES('8','icp','');
INSERT INTO em_options VALUES('9','footer_info','');
INSERT INTO em_options VALUES('10','admin_perpage_num','15');
INSERT INTO em_options VALUES('11','rss_output_num','10');
INSERT INTO em_options VALUES('12','rss_output_fulltext','y');
INSERT INTO em_options VALUES('13','index_lognum','10');
INSERT INTO em_options VALUES('14','index_comnum','10');
INSERT INTO em_options VALUES('15','index_twnum','10');
INSERT INTO em_options VALUES('16','index_newtwnum','5');
INSERT INTO em_options VALUES('17','index_newlognum','5');
INSERT INTO em_options VALUES('18','index_randlognum','5');
INSERT INTO em_options VALUES('19','index_hotlognum','5');
INSERT INTO em_options VALUES('20','comment_subnum','20');
INSERT INTO em_options VALUES('21','nonce_templet','default');
INSERT INTO em_options VALUES('22','admin_style','default');
INSERT INTO em_options VALUES('23','tpl_sidenum','1');
INSERT INTO em_options VALUES('24','comment_code','n');
INSERT INTO em_options VALUES('25','comment_needchinese','y');
INSERT INTO em_options VALUES('26','comment_interval','15');
INSERT INTO em_options VALUES('27','isgravatar','y');
INSERT INTO em_options VALUES('28','isthumbnail','y');
INSERT INTO em_options VALUES('29','comment_paging','y');
INSERT INTO em_options VALUES('30','comment_pnum','15');
INSERT INTO em_options VALUES('31','comment_order','newer');
INSERT INTO em_options VALUES('32','login_code','n');
INSERT INTO em_options VALUES('33','reply_code','n');
INSERT INTO em_options VALUES('34','iscomment','y');
INSERT INTO em_options VALUES('35','ischkcomment','n');
INSERT INTO em_options VALUES('36','ischkreply','n');
INSERT INTO em_options VALUES('37','isurlrewrite','0');
INSERT INTO em_options VALUES('38','isalias','n');
INSERT INTO em_options VALUES('39','isalias_html','n');
INSERT INTO em_options VALUES('40','isgzipenable','n');
INSERT INTO em_options VALUES('41','isxmlrpcenable','n');
INSERT INTO em_options VALUES('42','ismobile','y');
INSERT INTO em_options VALUES('43','isexcerpt','y');
INSERT INTO em_options VALUES('44','excerpt_subnum','300');
INSERT INTO em_options VALUES('45','istwitter','y');
INSERT INTO em_options VALUES('46','istreply','n');
INSERT INTO em_options VALUES('47','topimg','');
INSERT INTO em_options VALUES('48','custom_topimgs','a:0:{}');
INSERT INTO em_options VALUES('49','timezone','8');
INSERT INTO em_options VALUES('50','active_plugins','a:6:{i:0;s:13:\"tips/tips.php\";i:1;s:19:\"jiathis/jiathis.php\";i:2;s:19:\"sitemap/sitemap.php\";i:3;s:25:\"water_mark/water_mark.php\";i:4;s:27:\"goto_mobile/goto_mobile.php\";i:5;s:15:\"cover/cover.php\";}');
INSERT INTO em_options VALUES('51','widget_title','a:13:{s:7:\"blogger\";s:12:\"个人资料\";s:8:\"calendar\";s:6:\"日历\";s:7:\"twitter\";s:12:\"最新微语\";s:3:\"tag\";s:6:\"标签\";s:4:\"sort\";s:6:\"分类\";s:7:\"archive\";s:6:\"存档\";s:7:\"newcomm\";s:12:\"最新评论\";s:6:\"newlog\";s:12:\"最新文章\";s:10:\"random_log\";s:12:\"随机文章\";s:6:\"hotlog\";s:12:\"热门文章\";s:4:\"link\";s:6:\"链接\";s:6:\"search\";s:6:\"搜索\";s:11:\"custom_text\";s:15:\"自定义组件\";}');
INSERT INTO em_options VALUES('52','custom_widget','a:0:{}');
INSERT INTO em_options VALUES('53','widgets1','a:5:{i:0;s:8:\"calendar\";i:1;s:7:\"archive\";i:2;s:7:\"newcomm\";i:3;s:4:\"link\";i:4;s:6:\"search\";}');
INSERT INTO em_options VALUES('54','widgets2','');
INSERT INTO em_options VALUES('55','widgets3','');
INSERT INTO em_options VALUES('56','widgets4','');

DROP TABLE IF EXISTS em_navi;
CREATE TABLE `em_navi` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `naviname` varchar(30) NOT NULL DEFAULT '',
  `url` varchar(75) NOT NULL DEFAULT '',
  `newtab` enum('n','y') NOT NULL DEFAULT 'n',
  `hide` enum('n','y') NOT NULL DEFAULT 'n',
  `taxis` smallint(4) unsigned NOT NULL DEFAULT '0',
  `isdefault` enum('n','y') NOT NULL DEFAULT 'n',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `type_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO em_navi VALUES('1','首页','','n','n','1','y','1','0');
INSERT INTO em_navi VALUES('2','微语','t','n','n','5','y','2','0');
INSERT INTO em_navi VALUES('3','登录','admin','n','y','10','y','3','0');
INSERT INTO em_navi VALUES('4','照片','','n','n','3','n','4','1');
INSERT INTO em_navi VALUES('5','心情','','n','n','4','n','4','2');
INSERT INTO em_navi VALUES('6','旺记时尚包铺','http://33best.taobao.com/','y','n','6','n','0','0');
INSERT INTO em_navi VALUES('7','技术','','n','n','2','n','4','3');

DROP TABLE IF EXISTS em_reply;
CREATE TABLE `em_reply` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `tid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `date` bigint(20) NOT NULL,
  `name` varchar(20) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `hide` enum('n','y') NOT NULL DEFAULT 'n',
  `ip` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `gid` (`tid`),
  KEY `hide` (`hide`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS em_sort;
CREATE TABLE `em_sort` (
  `sid` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `sortname` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(200) NOT NULL DEFAULT '',
  `taxis` smallint(4) unsigned NOT NULL DEFAULT '0',
  `pid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO em_sort VALUES('1','照片','','1','0','');
INSERT INTO em_sort VALUES('2','心情','','2','0','');
INSERT INTO em_sort VALUES('3','技术','','3','0','左手代码，右手诗');

DROP TABLE IF EXISTS em_link;
CREATE TABLE `em_link` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `sitename` varchar(30) NOT NULL DEFAULT '',
  `siteurl` varchar(75) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `hide` enum('n','y') NOT NULL DEFAULT 'n',
  `taxis` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO em_link VALUES('2','旺记时尚包铺','http://33best.taobao.com/','','n','0');

DROP TABLE IF EXISTS em_tag;
CREATE TABLE `em_tag` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `tagname` varchar(60) NOT NULL DEFAULT '',
  `gid` text NOT NULL,
  PRIMARY KEY (`tid`),
  KEY `tagname` (`tagname`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO em_tag VALUES('1','百度',',2,');
INSERT INTO em_tag VALUES('2','云盘',',2,');
INSERT INTO em_tag VALUES('3','手机',',4,');
INSERT INTO em_tag VALUES('4','任务',',3,5,');
INSERT INTO em_tag VALUES('5','计划',',3,5,');
INSERT INTO em_tag VALUES('6','百达翡丽',',7,');
INSERT INTO em_tag VALUES('7','代购',',7,');
INSERT INTO em_tag VALUES('8','godaddy',',8,');
INSERT INTO em_tag VALUES('9','域名',',8,');
INSERT INTO em_tag VALUES('10','空间',',8,');
INSERT INTO em_tag VALUES('11','退款',',8,');

DROP TABLE IF EXISTS em_twitter;
CREATE TABLE `em_twitter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `img` varchar(200) DEFAULT NULL,
  `author` int(10) NOT NULL DEFAULT '1',
  `date` bigint(20) NOT NULL,
  `replynum` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `author` (`author`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO em_twitter VALUES('1','使用微语记录您身边的新鲜事','','1','1389449328','0');
INSERT INTO em_twitter VALUES('2','终于改写成适合sae环境了，用了sae环境的mysql变量和mc写缓存[耶]','','1','1389534832','0');
INSERT INTO em_twitter VALUES('3','红尘练心','','1','1395766511','0');
INSERT INTO em_twitter VALUES('4','从明天起，做一个幸福的人。喂马，砍柴，周游世界。','','1','1396198912','0');

DROP TABLE IF EXISTS em_user;
CREATE TABLE `em_user` (
  `uid` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL DEFAULT '',
  `nickname` varchar(20) NOT NULL DEFAULT '',
  `role` varchar(60) NOT NULL DEFAULT '',
  `ischeck` enum('n','y') NOT NULL DEFAULT 'n',
  `photo` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(60) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO em_user VALUES('1','bao0541','$P$BX4b9IJo2YdXRKqbkT.g8zxVXGF9de/','老徐','admin','n','','bao0541@live.cn','为爱混迹于大广州，普通又平方的PHP搬砖工程师');


#the end of backup